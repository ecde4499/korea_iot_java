package org.example.book_management_system.exception;

public class BookNotFoundException extends RuntimeException {

}
